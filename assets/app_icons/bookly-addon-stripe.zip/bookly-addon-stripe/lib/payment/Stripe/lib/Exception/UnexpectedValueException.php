<?php

namespace BooklyStripe\Lib\Payment\Lib\Stripe\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
