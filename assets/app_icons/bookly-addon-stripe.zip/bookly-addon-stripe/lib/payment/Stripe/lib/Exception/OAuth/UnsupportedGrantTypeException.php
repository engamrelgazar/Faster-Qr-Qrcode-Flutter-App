<?php

namespace BooklyStripe\Lib\Payment\Lib\Stripe\Exception\OAuth;

/**
 * UnsupportedGrantTypeException is thrown when an unuspported grant type
 * parameter is specified.
 */
class UnsupportedGrantTypeException extends OAuthErrorException
{
}
