<?php

namespace BooklyStripe\Lib\Payment\Lib\Stripe\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
