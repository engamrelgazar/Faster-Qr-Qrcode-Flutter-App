<?php

namespace BooklyStripe\Lib\Payment\Lib\Stripe\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
