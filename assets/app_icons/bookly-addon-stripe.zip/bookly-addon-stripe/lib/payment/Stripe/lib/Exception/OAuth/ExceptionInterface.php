<?php

namespace BooklyStripe\Lib\Payment\Lib\Stripe\Exception\OAuth;

/**
 * The base interface for all Stripe OAuth exceptions.
 */
interface ExceptionInterface extends \BooklyStripe\Lib\Payment\Lib\Stripe\Exception\ExceptionInterface
{
}
